<?php 
 
 $con = mysqli_connect("localhost","root","","BMICalc") or die("Couldn't connect");

?>